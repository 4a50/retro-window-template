import WindowCard from './Cards/WindowCard.js';
const Main = () => {
  return(
    <>
    <h1>Main</h1>
    <WindowCard/>
    </>
  )
}
export default Main;